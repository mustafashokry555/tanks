<!-- Footer opened -->
<div class="main-footer m-0 p-0 border-0 d-lg-block d-none">
    <div class="container-fluid pd-t-0-f ht-100p">
        <?php echo e(__('admin.copyrights')); ?> <span class="text-decoration-underline">Art4Muslim TEAM</span>
    </div>
</div>
<!-- Footer closed -->
<?php /**PATH D:\laragon\www\nabta.tech\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>