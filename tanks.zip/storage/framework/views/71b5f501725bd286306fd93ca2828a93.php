<?php $__env->startSection('title'); ?>
    <?php echo e(__('admin.sliders')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <!---Internal Owl Carousel css-->
    <link href="<?php echo e(URL::asset('assets/plugins/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
    <!---Internal  Multislider css-->
    <link href="<?php echo e(URL::asset('assets/plugins/multislider/multislider.css')); ?>" rel="stylesheet">
    <!--- Select2 css -->
    <link href="<?php echo e(URL::asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet">
    <style>
        .pagination-box {
            display: flex;
            justify-content: flex-end;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('admin.components.breadcrumb'); ?>
        <?php $__env->slot('li_1'); ?>
            <?php echo e(__('admin.all_sliders')); ?>

        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            <?php echo e(__('admin.control')); ?> <?php echo e(__('admin.sliders')); ?> !
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="card-title m-0"><?php echo e(__('admin.all_sliders')); ?></h4>
                    <?php if(isset($super_admin) || isset($slider_create)): ?>
                        <a href="<?php echo e(route('admin.sliders.create')); ?>" class="btn btn-primary button-icon"><i
                                class="fe fe-plus ml-2 font-weight-bolder"></i><?php echo e(__('admin.add_slider')); ?></a>
                    <?php endif; ?>
                </div>
                <div class="card-body table-responsive border-0">
                    <?php echo $__env->make('admin.layouts.session', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php $__env->startComponent('admin.components.errors'); ?>
                        <?php $__env->slot('id'); ?>
                            slider_id
                        <?php $__env->endSlot(); ?>
                    <?php echo $__env->renderComponent(); ?>
                    <table id="datatable" class="table table-bordered dt-responsive text-nowrap w-100">
                        <thead>
                            <tr style="cursor: pointer;">
                                <th class="fw-bold">#</th>
                                <th class="fw-bold"><?php echo e(__('admin.image')); ?></th>
                                <th class="fw-bold"><?php echo e(__('admin.title')); ?></th>
                                <th class="fw-bold"><?php echo e(__('admin.link')); ?></th>
                                <th class="fw-bold"><?php echo e(__('admin.display_status')); ?></th>
                                <th class="fw-bold"><?php echo e(__('admin.actions')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($sliders) == 0): ?>
                                <tr class="align-middle">
                                    <td colspan="100" class="text-center"><?php echo e(__('admin.no_data')); ?></td>
                                </tr>
                            <?php endif; ?>
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-id="<?php echo e($count + 1); ?>">
                                    <td style="width: 80px" class="align-middle"><?php echo e($count + 1); ?></td>
                                    <td class="align-middle"><img src="<?php echo e($slider->imageLink); ?>"
                                            alt="<?php echo e(__('admin.image')); ?>" style="width: 100px;" /></td>
                                    <td class="align-middle"><?php echo e($slider->title); ?></td>
                                    <td class="align-middle">
                                        <?php if($slider->link): ?>
                                            <a href="<?php echo e($slider->link); ?>" target="_blank"><?php echo e($slider->link); ?></a>
                                        <?php else: ?>
                                            <?php echo e(__('admin.unknown')); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td class="align-middle">
                                        <?php echo e($slider->displayed == 0 ? __('admin.hidden') : __('admin.displayed')); ?></td>
                                    <td class="align-middle">
                                        <div class="d-flex">
                                            <?php if(isset($super_admin) || isset($slider_edit)): ?>
                                                <form class="d-inline ml-2" action="<?php echo e(route('admin.sliders.display')); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <input type="hidden" name="slider_id" value="<?php echo e($slider->id); ?>" />
                                                    <button type="submit"
                                                        class="btn btn-outline-secondary  bg-primary text-dark btn-sm"
                                                        <?php if($slider->displayed == 1): ?> title="<?php echo e(__('admin.hide')); ?>" <?php else: ?> title="<?php echo e(__('admin.show')); ?>" <?php endif; ?>>
                                                        <i
                                                            class="<?php if($slider->displayed == 1): ?> fas fa-eye-slash <?php else: ?> fas fa-eye <?php endif; ?>"></i>
                                                    </button>
                                                </form>
                                                <a class="btn btn-outline-secondary bg-warning text-dark btn-sm ml-2"
                                                    title="<?php echo e(__('admin.edit')); ?>"
                                                    href="<?php echo e(route('admin.sliders.edit', [$slider->id])); ?>">
                                                    <i class="fas fa-pencil-alt"></i>
                                                </a>
                                            <?php endif; ?>
                                            <?php if(isset($super_admin) || isset($slider_delete)): ?>
                                                <button type="submit"
                                                    class="modal-effect btn btn-outline-secondary bg-danger text-dark btn-sm"
                                                    title="<?php echo e(__('admin.delete')); ?>" data-effect="effect-newspaper"
                                                    data-toggle="modal" href="#myModal<?php echo e($slider->id); ?>">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            <?php endif; ?>
                                        </div>

                                        <?php if(isset($super_admin) || isset($slider_delete)): ?>
                                            <div class="modal" id="myModal<?php echo e($slider->id); ?>">
                                                <div class="modal-dialog modal-dialog-centered" role="document">
                                                    <div class="modal-content modal-content-demo">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title"><?php echo e(__('admin.delete_slider')); ?></h5>
                                                            <button aria-label="Close" class="close" data-dismiss="modal"
                                                                type="button"><span
                                                                    aria-hidden="true">&times;</span></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p><?php echo e(__('admin.delete_slider_message')); ?></p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <form class="d-inline"
                                                                action="<?php echo e(route('admin.sliders.destroy')); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('Delete'); ?>
                                                                <input type="hidden" name="slider_id"
                                                                    value="<?php echo e($slider->id); ?>" />
                                                                <button type="button"
                                                                    class="btn btn-secondary waves-effect"
                                                                    data-dismiss="modal"><?php echo e(__('admin.back')); ?></button>
                                                                <button type="submit"
                                                                    class="btn btn-danger waves-effect waves-light"><?php echo e(__('admin.delete')); ?></button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="row">
                        <div class="col-12 pagination-box">
                            <?php echo e($sliders->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <!--Internal  Datepicker js -->
    <script src="<?php echo e(URL::asset('assets/plugins/jquery-ui/ui/widgets/datepicker.js')); ?>"></script>
    <!-- Internal Select2 js-->
    <script src="<?php echo e(URL::asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>
    <!-- Internal Modal js-->
    <script src="<?php echo e(URL::asset('assets/js/modal.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\nabta.tech\resources\views/admin/pages/sliders/index.blade.php ENDPATH**/ ?>