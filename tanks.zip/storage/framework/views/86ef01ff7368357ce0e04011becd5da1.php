<!-- main-header opened -->
<div class="main-header sticky side-header nav nav-item">
    <div class="container-fluid">
        <div class="main-header-left ">
            <div class="responsive-logo">
                <a href="<?php echo e(route('admin.home')); ?>"><img
                        src="<?php echo e($setting ? $setting->logoLink : URL::asset('assets/img/favicon.png')); ?>" class="logo-1"
                        alt="logo"></a>
                <a href="<?php echo e(route('admin.home')); ?>"><img
                        src="<?php echo e($setting ? $setting->logoLink : URL::asset('assets/img/favicon.png')); ?>" class="logo-2"
                        alt="logo"></a>
            </div>
            <div class="app-sidebar__toggle" data-toggle="sidebar">
                <a class="open-toggle" href="javascript:void();" onclick="sidebar_session(true, 1)"><i
                        class="header-icon fe fe-align-left"></i></a>
                <a class="close-toggle" href="javascript:void();" onclick="sidebar_session(true, 0)"><i
                        class="header-icons fe fe-x"></i></a>
            </div>
        </div>
        <?php echo $__env->make('admin.layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="main-header-right">
            <div class="nav nav-item  navbar-nav-right ml-auto">
                <div class="dropdown main-profile-menu nav nav-item nav-link">
                    <a class="profile-user d-flex" href=""><img alt=""
                            src="<?php echo e(auth()->user()->imageLink); ?>"></a>
                    <div class="dropdown-menu">
                        <div class="main-header-profile bg-primary p-3">
                            <div class="d-flex wd-100p">
                                <div class="main-img-user"><img alt="" src="<?php echo e(auth()->user()->imageLink); ?>"
                                        class=""></div>
                                <div class="mr-3 my-auto">
                                    <h6><?php echo e(auth()->user()->name); ?></h6>
                                </div>
                            </div>
                        </div>
                        <a class="dropdown-item " href="javascript:void();"
                            onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i
                                class="bx bx-log-out"></i> <?php echo e(__('admin.logout')); ?></a>
                        <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST"
                            style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /main-header -->
<?php /**PATH D:\laragon\www\nabta.tech\resources\views/admin/layouts/main-header.blade.php ENDPATH**/ ?>