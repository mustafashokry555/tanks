<?php $__env->startSection('title'); ?>
    <?php echo e(__('admin.contacts')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('admin.components.breadcrumb'); ?>
        <?php $__env->slot('li_1'); ?>
            <?php echo e(__('admin.all_contacts')); ?>

        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            <?php echo e(__('admin.control')); ?> <?php echo e(__('admin.all_contacts')); ?>!
        <?php $__env->endSlot(); ?>
        <?php $__env->startSection('css'); ?>
            <style>
                .pagination-box {
                    display: flex;
                    justify-content: flex-end;
                }

                .message-readed::after {
                    width: 0 !important;
                    height: 0 !important;
                }
            </style>
        <?php $__env->stopSection(); ?>
    <?php echo $__env->renderComponent(); ?>
    <div class="row">
        <div class="col-12">
            <!-- Right Sidebar -->
            <div class="mb-3">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title m-0"><?php echo e(__('admin.all_contacts')); ?></h4>
                    </div>
                    <div class="main-content-body main-content-body-mail card-body">
                        <?php echo $__env->make('admin.layouts.session', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php if(count($contacts) > 0): ?>
                            <div class="main-mail-options p-0">
                            </div>
                            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(isset($super_admin) || isset($contact_edit)): ?>
                                    <a href="<?php echo e(route('admin.contacts.show', $contact->id)); ?>">
                                <?php endif; ?>
                                <div class="main-mail-list <?php if($contact->read == 0): ?> font-weight-bolder <?php endif; ?>">
                                    <div class="main-mail-item unread">
                                        <div class="main-img-user <?php if($contact->read == 1): ?> message-readed <?php endif; ?>">
                                            <img alt="<?php echo e(__('admin.image')); ?>"
                                                src="<?php echo e(URL::asset('uploads/defaults/default.png')); ?>"></div>
                                        <div class="main-mail-body">
                                            <div class="main-mail-from text-dark">
                                                <?php echo e($contact->name); ?>

                                                <span
                                                    class="bg-dark text-white badge mr-2 lh-base"><?php echo e($contact->subject); ?></span>
                                            </div>
                                            <div class="main-mail-subject text-dark">
                                                <?php echo e($contact->email); ?>

                                            </div>
                                        </div>
                                        <div class="main-mail-date align-middle">
                                            <?php echo e($contact->created_at); ?>

                                        </div>
                                    </div>
                                </div>
                                <?php if(isset($super_admin) || isset($contact_edit)): ?>
                                    </a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="text-center">
                                <?php echo e(__('admin.no_messages')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="row mt-3">
                            <div class="col-12 pagination-box">
                                <?php echo e($contacts->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>

            </div> <!-- end Col-9 -->

        </div>

    </div><!-- End row -->
    <!-- End Page-content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(URL::asset('/assets/js/app.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\nabta.tech\resources\views/admin/pages/contacts/index.blade.php ENDPATH**/ ?>