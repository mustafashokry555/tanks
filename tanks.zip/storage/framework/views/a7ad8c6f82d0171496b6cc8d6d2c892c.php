<!-- start page title -->
<div class="row">
    <div class="col-12 py-3">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18"><?php echo e($title); ?></h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0 p-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($li_1); ?></a></li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->
<?php /**PATH D:\laragon\www\nabta.tech\resources\views/admin/components/breadcrumb.blade.php ENDPATH**/ ?>