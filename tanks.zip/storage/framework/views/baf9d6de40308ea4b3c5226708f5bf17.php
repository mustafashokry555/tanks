<?php $__env->startSection('title'); ?>
    <?php echo e(__('admin.dashboard')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
    <div class="breadcrumb-header justify-content-between">
        <div class="left-content">
            <div>
                <h2 class="main-content-title tx-24 mg-b-1 mg-b-lg-1"><?php echo e(__('admin.welcome_back')); ?></h2>
            </div>
        </div>
    </div>
    <!-- /breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row row-sm">
        <div class="col-lg-6 col-xl-3 col-12">
            <a href="<?php echo e(route('admin.admins.index')); ?>">
                <div class="card bg-primary-gradient text-white ">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-4">
                                <div class="icon1 mt-2 text-center">
                                    <i class="fe fe-users tx-40"></i>
                                </div>
                            </div>
                            <div class="col-8">
                                <div class="mt-0 text-center">
                                    <span class="text-white"><?php echo e(__('admin.total_admins')); ?></span>
                                    <h2 class="text-white mb-0"><?php echo e($total_admins); ?></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-6 col-xl-3 col-12">
            <a href="<?php echo e(route('admin.contacts.index')); ?>">
                <div class="card bg-info-gradient text-white ">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-4">
                                <div class="icon1 mt-2 text-center">
                                    <i class="fe fe-message-square tx-40"></i>
                                </div>
                            </div>
                            <div class="col-8">
                                <div class="mt-0 text-center">
                                    <span class="text-white"><?php echo e(__('admin.total_contacts')); ?></span>
                                    <h2 class="text-white mb-0"><?php echo e($total_contacts); ?></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-6 col-xl-3 col-12">
            <div class="card bg-dark text-white">
                <div class="card-body">
                    <div class="row">
                        <div class="col-4">
                            <div class="icon1 mt-2 text-center">
                                <i class="fe fe-message-square tx-40"></i>
                            </div>
                        </div>
                        <div class="col-8">
                            <div class="mt-0 text-center">
                                <span class="text-white"><?php echo e(__('admin.total_non_read_contacts')); ?></span>
                                <h2 class="text-white mb-0"><?php echo e($total_non_read_contacts); ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-3 col-12">
            <div class="card bg-danger-gradient text-white">
                <div class="card-body">
                    <div class="row">
                        <div class="col-4">
                            <div class="icon1 mt-2 text-center">
                                <i class="fe fe-message-square tx-40"></i>
                            </div>
                        </div>
                        <div class="col-8">
                            <div class="mt-0 text-center">
                                <span class="text-white"><?php echo e(__('admin.total_read_contacts')); ?></span>
                                <h2 class="text-white mb-0"><?php echo e($total_read_contacts); ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row row-sm">
        <div class="col-12">
            <div class="card">
                <div class="card-body table-striped table-responsive border-0 pb-0">
                    <h4 class="card-title" style="font-size: 13px;"><?php echo e(__('admin.last_5_admins')); ?></h4>
                    <table id="datatable" class="table table-bordered dt-responsive text-nowrap w-100">
                        <thead>
                            <tr style="cursor: pointer;">
                                <th class="fw-bold">#</th>
                                <th class="fw-bold"><?php echo e(__('admin.name')); ?></th>
                                <th class="fw-bold"><?php echo e(__('admin.email')); ?></th>
                                <th class="fw-bold"><?php echo e(__('admin.account_status')); ?></th>
                                <th class="fw-bold"><?php echo e(__('admin.joining_date')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($admins) == 0): ?>
                                <tr class="align-middle">
                                    <td colspan="100" class="text-center"><?php echo e(__('admin.no_data')); ?></td>
                                </tr>
                            <?php endif; ?>
                            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count => $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-id="<?php echo e($count + 1); ?>">
                                    <td style="width: 80px" class="align-middle"><?php echo e($count + 1); ?></td>
                                    <td class="align-middle"><?php echo e($admin->name); ?></td>
                                    <td class="align-middle"><?php echo e($admin->email ? $admin->email : __('admin.unknown')); ?>

                                    </td>
                                    <td class="align-middle"><?php echo e(__("admin.blocked_$admin->blocked")); ?></td>
                                    <td class="align-middle"><?php echo e($admin->created_at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(function() {
            $('.map-btn').click(function(event) {
                var lat = $(this).data('lat');
                var lng = $(this).data('lng');
                showMap(lat, lng);
            });
        });

        function showMap(lat, lng) {
            var url = "https://maps.google.com/?q=" + lat + "," + lng;
            window.open(url);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\nabta.tech\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>