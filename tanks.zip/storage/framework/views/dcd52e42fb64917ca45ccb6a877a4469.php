<!-- main-sidebar -->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar sidebar-scroll">
    <div class="main-sidebar-header active">
        <a class="desktop-logo logo-light active d-flex justify-contant-center align-items-center w-100" dir="ltr" href="<?php echo e(route('admin.home')); ?>">
            <img src="<?php echo e($setting ? $setting->logoLink : URL::asset('assets/img/favicon.png')); ?>" class="main-logo m-0"
                alt="logo">
            <span class="text-dark" style="font-size: x-large; font-weight: bold;"><?php echo e($setting->name_en); ?></span>
            </a>
        <a class="logo-icon mobile-logo icon-light active" href="<?php echo e(route('admin.home')); ?>"><img
                src="<?php echo e($setting ? $setting->logoLink : URL::asset('assets/img/favicon.png')); ?>" class="logo-icon"
                alt="logo"><span><?php echo e($setting->name_en); ?></span></a>
    </div>
    <div class="main-sidemenu">
        <div class="app-sidebar__user clearfix">
            <div class="dropdown user-pro-body">
                <div class="">
                    <img alt="user-img" class="avatar avatar-xl brround" src="<?php echo e(auth()->user()->imageLink); ?>"><span
                        class="avatar-status profile-status bg-green"></span>
                </div>
                <div class="user-info">
                    <h4 class="font-weight-semibold mt-3 mb-0"><?php echo e(auth()->user()->name); ?></h4>
                </div>
            </div>
        </div>

        <ul class="side-menu">
            <li class="side-item side-item-category"><?php echo e(__('admin.menu')); ?></li>

            <li class="slide">
                <a class="side-menu__item" href="<?php echo e(route('admin.home')); ?>"><i class="fe fe-home ml-3"
                        style="font-size: 16px"></i><span
                        class="side-menu__label"><?php echo e(__('admin.dashboard')); ?></span></a>
            </li>

            <?php if(isset($super_admin) ||
                    isset($admin_create) ||
                    isset($admin_edit) ||
                    isset($admin_delete)): ?>
                <li class="side-item side-item-category"><?php echo e(__('admin.users')); ?></li>

                <?php if(isset($super_admin) || isset($admin_create) || isset($admin_edit) || isset($admin_delete)): ?>
                    <li class="slide">
                        <a class="side-menu__item" data-toggle="slide" href="javascript:void();"><i
                                class="fe fe-users ml-3" style="font-size: 16px"></i><span
                                class="side-menu__label"><?php echo e(__('admin.employees')); ?></span><i
                                class="angle fe fe-chevron-down"></i></a>
                        <ul class="slide-menu">
                            <?php if(isset($super_admin) || isset($admin_edit) || isset($admin_delete)): ?>
                                <li><a class="slide-item"
                                        href="<?php echo e(route('admin.admins.index')); ?>"><?php echo e(__('admin.all_employees')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if(isset($super_admin) || isset($admin_create)): ?>
                                <li><a class="slide-item"
                                        href="<?php echo e(route('admin.admins.create')); ?>"><?php echo e(__('admin.add_employee')); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
            <?php endif; ?>


            <?php if(isset($super_admin) || isset($contact_control)): ?>
                <li class="side-item side-item-category"><?php echo e(__('admin.commerce')); ?></li>

                <?php if(isset($super_admin) || isset($contact_control)): ?>
                    <li class="slide">
                        <a class="side-menu__item" href="<?php echo e(route('admin.contacts.index')); ?>"><i
                                class="fe fe-message-square ml-3" style="font-size: 16px"></i><span
                                class="side-menu__label"><?php echo e(__('admin.contacts')); ?></span></a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>

            <?php if(isset($super_admin) ||
                    isset($setting_change) ||
                    isset($slider_create) ||
                    isset($slider_edit) ||
                    isset($slider_delete) ||
                    isset($social_create) ||
                    isset($social_edit) ||
                    isset($social_delete)): ?>
                <li class="side-item side-item-category"><?php echo e(__('admin.additional_data')); ?></li>

                <?php if(isset($super_admin) || isset($setting_change)): ?>
                    <li class="slide">
                        <a class="side-menu__item" data-toggle="slide" href="javascript:void();"><i
                                class="fe fe-settings ml-3" style="font-size: 16px"></i><span
                                class="side-menu__label"><?php echo e(__('admin.settings')); ?></span><i
                                class="angle fe fe-chevron-down"></i></a>
                        <ul class="slide-menu">
                            <li><a class="slide-item"
                                    href="<?php echo e(route('admin.settings.index')); ?>"><?php echo e(__('admin.main_settings')); ?></a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if(isset($super_admin) || isset($slider_create) || isset($slider_edit) || isset($slider_delete)): ?>
                    <li class="slide">
                        <a class="side-menu__item" data-toggle="slide" href="javascript:void();"><i
                                class="fe fe-sliders ml-3" style="font-size: 16px"></i><span
                                class="side-menu__label"><?php echo e(__('admin.sliders')); ?></span><i
                                class="angle fe fe-chevron-down"></i></a>
                        <ul class="slide-menu">
                            <?php if(isset($super_admin) || isset($slider_edit) || isset($slider_delete)): ?>
                                <li><a class="slide-item"
                                        href="<?php echo e(route('admin.sliders.index')); ?>"><?php echo e(__('admin.all_sliders')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if(isset($super_admin) || isset($slider_create)): ?>
                                <li><a class="slide-item"
                                        href="<?php echo e(route('admin.sliders.create')); ?>"><?php echo e(__('admin.add_slider')); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if(isset($super_admin) || isset($social_create) || isset($social_edit) || isset($social_delete)): ?>
                    <li class="slide">
                        <a class="side-menu__item" data-toggle="slide" href="javascript:void();"><i
                                class="fe fe-aperture ml-3" style="font-size: 16px"></i><span
                                class="side-menu__label"><?php echo e(__('admin.socials')); ?></span><i
                                class="angle fe fe-chevron-down"></i></a>
                        <ul class="slide-menu">
                            <?php if(isset($super_admin) || isset($social_edit) || isset($social_delete)): ?>
                                <li><a class="slide-item"
                                        href="<?php echo e(route('admin.socials.index')); ?>"><?php echo e(__('admin.all_socials')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if(isset($super_admin) || isset($social_create)): ?>
                                <li><a class="slide-item"
                                        href="<?php echo e(route('admin.socials.create')); ?>"><?php echo e(__('admin.add_social')); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
        </ul>
    </div>
</aside>
<!-- main-sidebar -->
<?php /**PATH D:\laragon\www\nabta.tech\resources\views/admin/layouts/main-sidebar.blade.php ENDPATH**/ ?>