<?php $__errorArgs = ["$id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger alert-dismissible fade show mb-2" role="alert">
        <span class="alert-inner--icon">
            <i class="fe fe-slash"></i>
        </span>
        <span class="alert-inner--text">
            <?php echo e($message); ?>

        </span>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php /**PATH D:\laragon\www\nabta.tech\resources\views/admin/components/errors.blade.php ENDPATH**/ ?>